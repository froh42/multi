#deck.blank.js

Deck.blank.js is an extension for the deck.js framework to allow blanking of the current slide, to draw the attention back to the presenter

At the moment, the key 'b' is hardcoded to blank/unblank.

##Todo

- make the blanking key configurable
- make the background-color during blanking configurable